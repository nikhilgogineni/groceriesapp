import 'package:flutter/material.dart';

final customColors = CustomColors();

class CustomColors {
  final Color green = const Color(0xFF53b175);
  final Color white = Colors.white;
  final Color black = Colors.black;

  // search box color //
  final Color searchColor = const Color(0xFFf2f3f2);

  // home page //
  final Color homeBackground = const Color(0xFFffffff);

  // colors in explore page //
  final Color backgroundWhite = const Color(0xFFf2f3f2);
  final Color lightBlue = const Color(0xFFeef7f1);
  final Color lightBlueBorder = const Color(0xFFcce8d6);
  final Color lightPink = const Color(0xFFfef6ed);
  final Color lightPinkBorder = const Color(0xFFfbce9d);
  final Color darkPink = const Color(0xFFfde8e4);
  final Color darkPinkBorder = const Color(0xFFfbd2c9);
  final Color violet = const Color(0xFFf4ebf7);
  final Color violetBorder = const Color(0xFFe6d2ed);
  final Color veryLightPink = const Color(0xFFfff8e5);
  final Color veryLightPinkBorder = const Color(0xFFfee8a5);

  // categories //
  final Color backgroundColorWhite = const Color(0xFFf1f1f1);

  // groceries_widget//
  final Color white1 = const Color(0xFFf1f1f1);

  //text color in cart view //
  final Color grey = const Color(0xFF999a99);
}
