import 'package:flutter/material.dart';
import 'package:groceries_app/constants/colors.dart';

class CustomGroceriesWidget extends StatelessWidget {
  String image;
  String textName;
  String quantity;
  String price;
  CustomGroceriesWidget(
      {Key? key,
      required this.image,
      required this.textName,
      required this.quantity,
      required this.price})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: customColors.white1, width: 2.8),
      ),
      child: ClipRect(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Image.asset(image, height: 90, width: 90),
              ),
            ),
            Text(textName,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            Text(quantity),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(price,
                      style:
                          const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  Container(
                    decoration: BoxDecoration(
                        color: customColors.green,
                        borderRadius: BorderRadius.circular(15)),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Icon(Icons.add, color: customColors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
