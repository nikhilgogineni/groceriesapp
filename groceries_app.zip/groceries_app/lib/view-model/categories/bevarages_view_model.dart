import 'package:flutter/material.dart';
import 'package:groceries_app/utils/email_authentication.dart';

class BeveragesViewModel extends ChangeNotifier {
  EmailAuthentication emailAuth = EmailAuthentication();

  // Future<ContentItem> fetchData() async {
  //   var firestoreInstance = FirebaseFirestore.instance;
  //   var databaseInstance = FirebaseDatabase.instance.ref("groceries/bevarages");
  //
  //   var firestoreData =
  //       await firestoreInstance.collection("beverages").doc().get();
  //   var databaseDataSnapshot = await databaseInstance.once();
  //   var databaseData =
  //       databaseDataSnapshot.snapshot.value as Map<String, dynamic>;
  //
  //   ContentItem contentItem = ContentItem(
  //     image: firestoreData["image"],
  //     name: databaseData["name"],
  //     price: databaseData["price"],
  //   );
  //   return contentItem;
  // }
}
