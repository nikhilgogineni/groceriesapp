import 'package:flutter/material.dart';


class HomePageViewModel extends ChangeNotifier {
  int selectedIndex = 0;
}
