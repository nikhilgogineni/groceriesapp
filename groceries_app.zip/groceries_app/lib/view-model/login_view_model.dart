import 'package:flutter/cupertino.dart';
import 'package:groceries_app/utils/email_authentication.dart';

class LoginViewModel extends ChangeNotifier {
  EmailAuthentication emailAuth = EmailAuthentication();
}
