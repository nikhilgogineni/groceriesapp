import 'package:flutter/cupertino.dart';
import 'package:groceries_app/utils/email_authentication.dart';

class RegisterViewModel extends ChangeNotifier {
  EmailAuthentication emailAuth = EmailAuthentication();

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
}
