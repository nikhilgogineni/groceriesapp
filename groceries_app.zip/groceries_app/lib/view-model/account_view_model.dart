import 'package:flutter/material.dart';
import 'package:groceries_app/utils/email_authentication.dart';

class AccountViewModel extends ChangeNotifier {
  EmailAuthentication emailAuth = EmailAuthentication();
  int selectedIndex = 4;
}
