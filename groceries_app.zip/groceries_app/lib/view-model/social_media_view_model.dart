import 'package:flutter/material.dart';

class SocialMediaViewModel extends ChangeNotifier {}
