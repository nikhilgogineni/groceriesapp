import 'package:flutter/material.dart';

class CartViewModel extends ChangeNotifier {
  int selectedIndex = 2;
}
