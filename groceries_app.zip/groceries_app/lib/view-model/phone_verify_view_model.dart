import 'package:flutter/material.dart';
import 'package:groceries_app/utils/phone_authentication.dart';

class PhoneVerifyViewModel extends ChangeNotifier {
  PhoneAuthentication phoneAuth = PhoneAuthentication();
  String? verification;
}
