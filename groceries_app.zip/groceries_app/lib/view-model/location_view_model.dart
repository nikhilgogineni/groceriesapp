import 'package:flutter/material.dart';

class LocationViewModel extends ChangeNotifier {}
