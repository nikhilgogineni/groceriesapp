import 'package:flutter/material.dart';

class GroceriesItemViewModel extends ChangeNotifier {}
