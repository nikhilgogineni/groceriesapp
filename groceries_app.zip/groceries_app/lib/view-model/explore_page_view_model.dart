import 'package:flutter/material.dart';

class ExplorePageViewModel extends ChangeNotifier {
  int selectedIndex = 1;
}
