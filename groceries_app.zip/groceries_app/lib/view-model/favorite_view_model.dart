import 'package:flutter/material.dart';

class FavoriteViewModel extends ChangeNotifier {
  int selectedIndex = 3;
}
