import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class Cart with ChangeNotifier {
  List items_ = [];
  List get items => items_;
  List get cartItems => items_;

  Future getData() async {
    var response = FirebaseDatabase.instance
      ..ref("groceries/bevarages");
    items_ = response as List;
    notifyListeners();
  }

  void addtocart(cartItem) {
    items_.add(cartItem);
    notifyListeners();
  }

  void addAllToCart(cartItem) {
    items_.addAll(cartItem);
    notifyListeners();
  }

  void removefromcart(cartItem) {
    items_.remove(cartItem);
    notifyListeners();
  }
}
