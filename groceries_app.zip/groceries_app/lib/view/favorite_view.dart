import 'package:flutter/material.dart';
import 'package:groceries_app/custom_widgets/CustomButton.dart';
import 'package:groceries_app/utils/bottom_navigation.dart';
import 'package:groceries_app/view-model/favorite_view_model.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import 'package:groceries_app/model/cart.dart';
import 'package:groceries_app/model/favorite.dart';

class FavoriteView extends StatefulWidget {
  const FavoriteView({Key? key}) : super(key: key);

  @override
  State<FavoriteView> createState() => _FavoriteViewState();
}

class _FavoriteViewState extends State<FavoriteView> {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<Cart>(context);
    final providerFav = Provider.of<Favourite>(context);
    final items = providerFav.favouriteItems;
    return ViewModelBuilder<FavoriteViewModel>.reactive(
      viewModelBuilder: () => FavoriteViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: const Text("Favourites"),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              ListView.builder(
                shrinkWrap: true,
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final cartItem = items[index];
                  return ListTile(
                    leading: Image.network(cartItem["image"]),
                    title: Text(cartItem["name"]),
                    subtitle: Text(cartItem["price"]),
                    trailing: IconButton(
                        onPressed: () {
                          providerFav.addToFavourite(cartItem);
                        },
                        icon: const Icon(Icons.delete)),
                  );
                },
              ),
              const SizedBox(
                height: 420,
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: InkWell(
                  onTap: () {
                    final cartItem = items;
                    provider.addAllToCart(cartItem);
                  },
                  child: const CustomButton(
                      textName: "Add All to Cart",
                      color1: Color(0xFF53b175),
                      color2: Colors.white),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
