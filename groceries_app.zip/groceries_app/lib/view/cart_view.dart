import 'package:flutter/material.dart';
import 'package:groceries_app/utils/bottom_navigation.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:groceries_app/view-model/cart_view_model.dart';
import 'package:groceries_app/model/cart.dart';
import 'package:groceries_app/constants/colors.dart';
import 'package:groceries_app/custom_widgets/CustomButton.dart';
import 'package:groceries_app/utils/order_accepted.dart';

class CartView extends StatefulWidget {
  const CartView({Key? key}) : super(key: key);

  @override
  State<CartView> createState() => _CartViewState();
}

class _CartViewState extends State<CartView> {
  int itemCount = 1;
  double totalPrice = 0.0;

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<Cart>(context);
    final items = provider.cartItems;
    return ViewModelBuilder<CartViewModel>.reactive(
      viewModelBuilder: () => CartViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: const Text("MyCart"),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              ListView.builder(
                shrinkWrap: true,
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final cartItem = items[index];
                  double price = double.parse(cartItem["price"]) * itemCount;
                  double totalPrice = price * items.length;

                  return ListTile(
                    leading:
                        Image.network(cartItem["image"], height: 40, width: 40),
                    title: Text(cartItem["name"]),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("\$$price".toString()),
                        Row(
                          children: [
                            InkWell(
                              onTap: () {
                                setState(() {
                                  itemCount--;
                                });
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    color: customColors.green,
                                    borderRadius: BorderRadius.circular(15)),
                                child: Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Icon(Icons.remove,
                                      color: customColors.white),
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 4,
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  color: customColors.white,
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(
                                    color: customColors.green,
                                  )),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Text(itemCount.toString(),
                                    style:
                                        TextStyle(color: customColors.green)),
                              ),
                            ),
                            const SizedBox(
                              width: 4,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  itemCount++;
                                });
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    color: customColors.green,
                                    borderRadius: BorderRadius.circular(15)),
                                child: Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Icon(Icons.add,
                                      color: customColors.white),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    trailing: IconButton(
                        onPressed: () {
                          provider.removefromcart(cartItem);
                        },
                        icon: const Icon(Icons.delete)),
                  );
                },
              ),
              const SizedBox(
                height: 440,
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: InkWell(
                  onTap: () {
                    showModalBottomSheet(
                      isDismissible: true,
                      isScrollControlled: true,
                      enableDrag: true,
                      context: context,
                      builder: (context) {
                        return Padding(
                          padding: const EdgeInsets.all(15),
                          child: SizedBox(
                            height: 470,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text("Checkout",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600)),
                                    IconButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        icon: const Icon(Icons.close)),
                                  ],
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Delivery",
                                        style: TextStyle(
                                            color: customColors.grey,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600)),
                                    Row(
                                      children: [
                                        const Text("Select Method",
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold)),
                                        IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.chevron_right,
                                              color: customColors.black,
                                              size: 26,
                                            ))
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Payment",
                                        style: TextStyle(
                                            color: customColors.grey,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600)),
                                    Row(
                                      children: [
                                        Image.asset(
                                            "assets/images/payment_card.png"),
                                        IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.chevron_right,
                                              color: customColors.black,
                                              size: 26,
                                            ))
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Promo Code",
                                        style: TextStyle(
                                            color: customColors.grey,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600)),
                                    Row(
                                      children: [
                                        const Text("Pick Discount",
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold)),
                                        IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.chevron_right,
                                              color: customColors.black,
                                              size: 26,
                                            ))
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Total Cost",
                                        style: TextStyle(
                                            color: customColors.grey,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600)),
                                    Row(
                                      children: [
                                        Text(totalPrice.toString(),
                                            style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold)),
                                        IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.chevron_right,
                                              color: customColors.black,
                                              size: 26,
                                            ))
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                const Text("By placing your order you agree to our",
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w400)),
                                const Row(
                                  children: [
                                    Text("Terms ",
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold)),
                                    Text(" and "),
                                    Text(" Conditions",
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                Padding(
                                    padding: const EdgeInsets.all(20),
                                    child: InkWell(
                                      onTap: () {
                                        Navigator.of(context)
                                            .pushAndRemoveUntil(
                                                MaterialPageRoute(
                                                  builder: (context) =>
                                                      const OrderAccepted(),
                                                ),
                                                (route) => false);
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: customColors.green,
                                          borderRadius:
                                              BorderRadius.circular(20),
                                        ),
                                        child: Center(
                                            child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Text(
                                            "Checkout",
                                            style: TextStyle(
                                              color: customColors.white,
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        )),
                                      ),
                                    )),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                  child: CustomButton(
                    textName: "Place Order",
                    color1: customColors.green,
                    color2: customColors.white,
                  ),
                ),
              )
            ],
          ),
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
