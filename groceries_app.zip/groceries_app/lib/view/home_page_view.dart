import 'package:flutter/material.dart';
import 'package:groceries_app/utils/bottom_navigation.dart';
import 'package:groceries_app/custom_widgets/custom_groceries_widget.dart';
import 'package:groceries_app/view-model/home_page_view_model.dart';
import 'package:stacked/stacked.dart';

import '../constants/colors.dart';

class HomePageView extends StatefulWidget {
  const HomePageView({Key? key}) : super(key: key);

  @override
  State<HomePageView> createState() => _HomePageView();
}

class _HomePageView extends State<HomePageView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomePageViewModel>.reactive(
      viewModelBuilder: () => HomePageViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        backgroundColor: customColors.homeBackground,
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              const SizedBox(
                height: 40,
              ),
              Center(
                child: Image.asset(
                  "assets/images/carrot.png",
                  height: 40,
                  width: 40,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.location_pin),
                  Text(
                    " Dhaka,",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    " Banassre",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Container(
                  decoration: BoxDecoration(
                    color: customColors.searchColor,
                    borderRadius: const BorderRadius.all(
                      Radius.circular(15),
                    ),
                  ),
                  child: TextFormField(
                    decoration: const InputDecoration(
                        hintText: "Search store",
                        prefixIcon: Icon(Icons.search),
                        border: InputBorder.none),
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Container(
                child: Image.asset("assets/images/fresh_vegetables.png"),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
                child: SizedBox(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Exclusive Offer",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w800,
                              )),
                          Text(
                            "See all",
                            style: TextStyle(
                              color: customColors.green,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.65,
                        ),
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: InkWell(
                              onTap: () {
                                // Navigator.of(context).push(MaterialPageRoute(
                                //   builder: (context) => GroceriesItemView(
                                //       title: "organic banana"),
                                // ));
                              },
                              child: CustomGroceriesWidget(
                                  image: "assets/groceries_items/banana.png",
                                  textName: "Organic Nanana",
                                  quantity: "7pcs,Pricing",
                                  price: "\$4.99"),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: CustomGroceriesWidget(
                                image: "assets/groceries_items/apple.png",
                                textName: "Apple",
                                quantity: "7pcs.Pricing",
                                price: "\$4.99"),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
                child: SizedBox(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Best Selling",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w800,
                              )),
                          Text(
                            "See all",
                            style: TextStyle(
                              color: customColors.green,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.65,
                        ),
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: CustomGroceriesWidget(
                                image:
                                    "assets/groceries_items/bell_peppers.png",
                                textName: "Bell Peppers",
                                quantity: "7pcs,Pricing",
                                price: "\$4.99"),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: CustomGroceriesWidget(
                                image: "assets/groceries_items/ginger.png",
                                textName: "Ginger",
                                quantity: "7pcs,Pricing",
                                price: "\$4.99"),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
                child: SizedBox(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Groceries",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w800,
                              )),
                          Text(
                            "See all",
                            style: TextStyle(
                              color: customColors.green,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      ListView(
                        shrinkWrap: true,
                        children: [
                          Container(
                            width: 50,
                            decoration: BoxDecoration(
                                color: const Color(0xFFfef1e4),
                                borderRadius: BorderRadius.circular(20)),
                            child: Row(
                              children: [
                                Image.asset("assets/groceries_items/pulses.png",
                                    height: 90, width: 90),
                                const SizedBox(
                                  height: 70,
                                ),
                                const Text("Pulses", style: TextStyle(fontSize: 18)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.65,
                        ),
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: CustomGroceriesWidget(
                                image: "assets/groceries_items/beef_bone.png",
                                textName: "Beef Bone",
                                quantity: "7pcs,Pricing",
                                price: "\$4.99"),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: CustomGroceriesWidget(
                                image:
                                    "assets/groceries_items/broiler_chicken.png",
                                textName: "Broiler Chicken",
                                quantity: "7pcs,Pricing",
                                price: "\$4.99"),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
