import 'package:flutter/material.dart';
import 'package:groceries_app/view-model/phone_validation_view_model.dart';
import 'package:stacked/stacked.dart';

class PhoneValidationView extends StatefulWidget {
  const PhoneValidationView({Key? key}) : super(key: key);

  @override
  State<PhoneValidationView> createState() => _PhoneValidationViewState();
}

class _PhoneValidationViewState extends State<PhoneValidationView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PhoneValidationViewModel>.reactive(
      viewModelBuilder: () => PhoneValidationViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        floatingActionButton: FloatingActionButton(
            onPressed: () {
              setState(() {
                viewModel.phoneAuth.verifyPhoneNumber(context);
              });
            },
            child: const Icon(Icons.chevron_right)),
        body: Column(
          children: [
            const SizedBox(height: 40),
            const Text("Enter Mobile Number"),
            const SizedBox(height: 20),
            TextFormField(
              inputFormatters: const [],
              controller: viewModel.phoneAuth.phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(hintText: "Enter Mobile Number"),
            ),
          ],
        ),
      ),
    );
  }
}
