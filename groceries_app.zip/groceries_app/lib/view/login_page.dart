import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceries_app/view/home_page_view.dart';
import 'package:groceries_app/view-model/login_view_model.dart';
import 'package:groceries_app/view/register_view.dart';
import 'package:stacked/stacked.dart';

import 'package:groceries_app/custom_widgets/CustomButton.dart';

class LoginView extends StatefulWidget {
  const LoginView({Key? key}) : super(key: key);

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return ViewModelBuilder<LoginViewModel>.reactive(
      viewModelBuilder: () => LoginViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          scrollDirection: Axis.vertical,
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(
                        60,
                      ),
                      child: Image.asset(
                        "assets/images/carrot.png",
                        height: 70,
                        width: 70,
                      ),
                    ),
                  ),
                ),
                const ListTile(
                  title: Padding(
                    padding: EdgeInsets.only(
                      bottom: 8,
                    ),
                    child: Text(
                      "Login",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  subtitle: Text(
                    "Enter your Email and password",
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                ListTile(
                  title: const Text(
                    "Email",
                  ),
                  subtitle: TextFormField(
                    controller: viewModel.emailAuth.emailController,
                    decoration: const InputDecoration(hintText: "Email"),
                    validator: (email) {
                      if (email == null || email.isEmpty) {
                        return "Enter email";
                      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                          .hasMatch(email)) {
                        return "Invalid email";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                ListTile(
                  title: const Text(
                    "Password",
                  ),
                  subtitle: TextFormField(
                    controller: viewModel.emailAuth.passwordController,
                    decoration: const InputDecoration(
                      hintText: "Password",
                      suffixIcon: Icon(Icons.visibility),
                    ),
                    validator: (password) {
                      if (password == null || password.isEmpty) {
                        return "Enter password";
                      } else if (!RegExp(
                              r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$')
                          .hasMatch(password)) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Text("invalid password format"),
                          showCloseIcon: true,
                        ));
                      } else {
                        return null;
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: InkWell(
                    onTap: () async {
                      if (formKey.currentState!.validate()) {
                        try {
                          await viewModel.emailAuth.signIn();
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (context) => const HomePageView(),
                              ),
                              (route) => false);
                        } on FirebaseAuthException catch (e) {
                          if (e.code == "user-not-found") {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text("user not found"),
                              showCloseIcon: true,
                            ));
                          } else if (e.code == "wrong-password") {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text("wrong password"),
                              showCloseIcon: true,
                            ));
                          }
                        }
                      }
                    },
                    child: const CustomButton(
                        textName: "LogIn",
                        color1: Color(0xFF53b175),
                        color2: Colors.white),
                  ),
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "Don't have an account?",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (context) => const RegisterView(),
                              ),
                              (route) => false);
                        },
                        child: const Text(
                          "Sign up",
                          style: TextStyle(
                              color: Color(0xFF53b175),
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
