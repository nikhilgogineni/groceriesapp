import 'package:flutter/material.dart';
import 'package:groceries_app/view/login_page.dart';
import 'package:stacked/stacked.dart';
import 'package:groceries_app/view-model/location_view_model.dart';

class LocationView extends StatefulWidget {
  const LocationView({Key? key}) : super(key: key);

  @override
  State<LocationView> createState() => _LocationViewState();
}

class _LocationViewState extends State<LocationView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LocationViewModel>.reactive(
      viewModelBuilder: () => LocationViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              const SizedBox(
                height: 60,
              ),
              Container(
                child: Center(
                  child: Image.asset("assets/images/location.png"),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              const Center(
                child: Text("Select your Location",
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              ),
              const SizedBox(
                height: 10,
              ),
              const Center(
                child: Text(
                  "Switch on your location to stay in tune with",
                  textAlign: TextAlign.center,
                ),
              ),
              const Center(
                child: Text("what’s happening in your area"),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 40),
                    const Text("your zone"),
                    const SizedBox(height: 10),
                    TextFormField(
                      decoration: const InputDecoration(
                        hintText: "Enter your zone",
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text("your area"),
                    const SizedBox(height: 10),
                    TextFormField(
                      decoration: const InputDecoration(hintText: "Enter your area"),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (context) => const LoginView(),
                              ),
                              (route) => false);
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFF53b175),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Center(
                              child: Padding(
                            padding: EdgeInsets.all(20),
                            child: Text(
                              "Submit",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
