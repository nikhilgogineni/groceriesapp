import 'package:flutter/material.dart';
import 'package:groceries_app/view/location_view.dart';
import 'package:groceries_app/view-model/social_media_view_model.dart';
import 'package:stacked/stacked.dart';

class SocialMediaView extends StatefulWidget {
  const SocialMediaView({Key? key}) : super(key: key);

  @override
  State<SocialMediaView> createState() => _SocialMediaViewState();
}

class _SocialMediaViewState extends State<SocialMediaView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SocialMediaViewModel>.reactive(
      viewModelBuilder: () => SocialMediaViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          scrollDirection: Axis.vertical,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Center(
                  child: Image.asset(
                    "assets/images/vegetable_basket.png",
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Get your groceries",
                          style: TextStyle(
                              fontSize: 25, fontWeight: FontWeight.w800)),
                      const Text("with nector",
                          style: TextStyle(
                              fontSize: 25, fontWeight: FontWeight.w800)),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(hintText: "Phone Number"),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      const Center(
                        child: Text("or connect with social media",
                            style: TextStyle(fontSize: 16)),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Center(
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context).pushAndRemoveUntil(
                                MaterialPageRoute(
                                  builder: (context) => const LocationView(),
                                ),
                                (route) => false);
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF5383ec),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Center(
                                child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 20,
                                  ),
                                  ImageIcon(
                                      AssetImage(
                                          "assets/images/google_icon.png"),
                                      color: Colors.white),
                                  SizedBox(
                                    width: 40,
                                  ),
                                  Text("Continue with Google",
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white)),
                                ],
                              ),
                            )),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFF4a66ac),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Center(
                              child: Padding(
                            padding: EdgeInsets.all(20),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 20,
                                ),
                                ImageIcon(
                                    AssetImage(
                                        "assets/images/facebook_icon.png"),
                                    color: Colors.white),
                                SizedBox(
                                  width: 40,
                                ),
                                Text("Continue with Facebook",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white)),
                              ],
                            ),
                          )),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
