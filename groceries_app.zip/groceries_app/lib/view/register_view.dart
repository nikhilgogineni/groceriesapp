import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceries_app/custom_widgets/CustomButton.dart';
import 'package:groceries_app/view/login_page.dart';
import 'package:groceries_app/view-model/rgister_view_model.dart';
import 'package:stacked/stacked.dart';

class RegisterView extends StatefulWidget {
  const RegisterView({Key? key}) : super(key: key);

  @override
  State<RegisterView> createState() => _RegisterViewState();
}

class _RegisterViewState extends State<RegisterView> {
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return ViewModelBuilder<RegisterViewModel>.reactive(
      viewModelBuilder: () => RegisterViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          scrollDirection: Axis.vertical,
          child: Form(
            key: formKey,
            child: Column(
              children: [
                const SizedBox(
                  height: 50,
                ),
                Container(
                  child: Center(
                    child: Image.asset("assets/images/carrot.png",
                        height: 70, width: 70),
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                const ListTile(
                  title: Text(
                    "Sign Up",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    "Enter your Credentials to continue",
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                ListTile(
                  title: const Text(
                    "Username",
                  ),
                  subtitle: TextFormField(
                    controller: viewModel.emailAuth.usernameController,
                    decoration: const InputDecoration(
                      hintText: "Username",
                    ),
                    validator: (name) {
                      if (name == null || name.isEmpty) {
                        return "Enter username";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                ListTile(
                  title: const Text(
                    "Email",
                  ),
                  subtitle: TextFormField(
                    controller: viewModel.emailAuth.emailController,
                    decoration: const InputDecoration(
                      hintText: "Email",
                    ),
                    validator: (email) {
                      if (email == null || email.isEmpty) {
                        return "Enter email";
                      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                          .hasMatch(email)) {
                        return "Invalid email";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                ListTile(
                  title: const Text(
                    "Password",
                  ),
                  subtitle: TextFormField(
                    controller: viewModel.emailAuth.passwordController,
                    decoration: const InputDecoration(
                      hintText: "Password",
                    ),
                    validator: (password) {
                      if (password == null || password.isEmpty) {
                        return "Enter password";
                      } else if (!RegExp(
                              r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$')
                          .hasMatch(password)) {
                        return "invalid password format";
                      } else {
                        return null;
                      }
                    },
                  ),
                  trailing: const Icon(
                    Icons.visibility_off,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: 10,
                    left: 15,
                  ),
                  child: Row(
                    children: [
                      const Text(
                        "By continuing you agree to our ",
                        style: TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      InkWell(
                        onTap: () {},
                        child: const Text(
                          "Terms of Service",
                          style: TextStyle(
                            color: Color(0xFF53b175),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 15,
                    bottom: 10,
                  ),
                  child: Row(
                    children: [
                      const Text(
                        "and ",
                        style: TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      InkWell(
                        onTap: () {},
                        child: const Text(
                          "Privacy Policy",
                          style: TextStyle(
                            color: Color(0xFF53b175),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: InkWell(
                    onTap: () async {
                      if (formKey.currentState!.validate()) {
                        try {
                          await viewModel.emailAuth.register();
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text("registered successfully"),
                            showCloseIcon: true,
                          ));
                        } on FirebaseAuthException catch (e) {
                          if (e.code == "email-already-in-use") {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text("email already in use"),
                              showCloseIcon: true,
                            ));
                          }
                        }
                      }
                    },
                    child: const CustomButton(
                        textName: "Sign up",
                        color1: Color(0xFF53b175),
                        color2: Colors.white),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Already have an account? ",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              builder: (context) => const LoginView(),
                            ),
                            (route) => false);
                      },
                      child: const Text(
                        "Sign in",
                        style: TextStyle(
                          color: Color(0xFF53b175),
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
