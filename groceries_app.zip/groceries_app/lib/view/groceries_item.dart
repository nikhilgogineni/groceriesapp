import 'package:flutter/material.dart';
import 'package:groceries_app/constants/colors.dart';
import 'package:groceries_app/view-model/groceries_item_view_model.dart';
import 'package:stacked/stacked.dart';

class GroceriesItemView extends StatefulWidget {
  String title;
  String image;
  String price;
  VoidCallback onPressed;
  Icon icon;
  GroceriesItemView(
      {Key? key,
      required this.title,
      required this.image,
      required this.price,
      required this.onPressed,
      required this.icon})
      : super(key: key);

  @override
  State<GroceriesItemView> createState() => _GroceriesItemViewState();
}

class _GroceriesItemViewState extends State<GroceriesItemView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GroceriesItemViewModel>.reactive(
      viewModelBuilder: () => GroceriesItemViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          backgroundColor: customColors.backgroundWhite,
        ),
        body: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  color: customColors.backgroundWhite,
                  borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(25),
                      bottomRight: Radius.circular(25))),
              child: Center(
                child: ClipRect(
                  child: Image.network(
                    widget.image,
                    height: 250,
                    width: 250,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(widget.title,
                      style: const TextStyle(
                          fontSize: 25, fontWeight: FontWeight.w800)),
                  IconButton(onPressed: widget.onPressed, icon: widget.icon),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Text("\$${widget.price}",
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Container(
                decoration: BoxDecoration(
                  color: customColors.green,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                    child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    "Add to Basket",
                    style: TextStyle(
                      color: customColors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )),
              ),
            )
          ],
        ),
      ),
    );
  }
}
