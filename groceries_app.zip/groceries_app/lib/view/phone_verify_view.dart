import 'package:flutter/material.dart';
import 'package:groceries_app/view-model/phone_verify_view_model.dart';
import 'package:stacked/stacked.dart';

class PhoneVerifyView extends StatefulWidget {
  const PhoneVerifyView({Key? key}) : super(key: key);

  @override
  State<PhoneVerifyView> createState() => _PhoneVerifyViewState();
}

class _PhoneVerifyViewState extends State<PhoneVerifyView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PhoneVerifyViewModel>.reactive(
      viewModelBuilder: () => PhoneVerifyViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        floatingActionButton: FloatingActionButton(
            onPressed: () {
              setState(() {
                // viewModel.phoneAuth.sighInPhoneNumber();
              });
            },
            child: const Icon(Icons.chevron_right)),
        appBar: AppBar(),
        body: Column(
          children: [
            const Text("Verify Mobile Number"),
            TextFormField(
              controller: viewModel.phoneAuth.phoneController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: "Enter otp code"),
            ),
          ],
        ),
      ),
    );
  }
}
