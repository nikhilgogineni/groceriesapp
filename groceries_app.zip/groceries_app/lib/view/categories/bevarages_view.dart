import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:groceries_app/view-model/categories/bevarages_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';

import 'package:groceries_app/model/cart.dart';
import 'package:groceries_app/model/favorite.dart';
import 'package:groceries_app/view/groceries_item.dart';

import '../../constants/colors.dart';

class BeveragesView extends StatefulWidget {
  const BeveragesView({Key? key}) : super(key: key);

  @override
  State<BeveragesView> createState() => _BeveragesViewState();
}

class _BeveragesViewState extends State<BeveragesView> {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<Cart>(context);
    final providerFav = Provider.of<Favourite>(context);
    return ViewModelBuilder<BeveragesViewModel>.reactive(
      viewModelBuilder: () => BeveragesViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: const Text("Beverages",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          centerTitle: true,
        ),
        body: StreamBuilder(
          stream: viewModel.emailAuth.reference.onValue,
          builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
            if (snapshot.hasData) {
              Map<dynamic, dynamic> data =
                  snapshot.data!.snapshot.value as dynamic;
              List<dynamic> list = [];
              list.clear();
              list = data.values.toList();

              return GridView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, childAspectRatio: 0.73),
                itemCount: snapshot.data!.snapshot.children.length,
                itemBuilder: (context, index) {
                  final cartItem = list[index];
                  final image = cartItem["image"];
                  final name = cartItem["name"];
                  final price = cartItem["price"];

                  return Padding(
                    padding: const EdgeInsets.all(6),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: customColors.backgroundColorWhite,
                            width: 2.8),
                      ),
                      child: ClipRect(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: InkWell(
                                    onTap: () {
                                      Navigator.of(context)
                                          .push(MaterialPageRoute(
                                        builder: (context) => GroceriesItemView(
                                          title: name,
                                          image: image,
                                          price: price,
                                          onPressed: () => providerFav
                                              .addToFavourite(cartItem),
                                          icon: providerFav.isExist(cartItem)
                                              ? const Icon(
                                                  Icons.favorite,
                                                  color: Colors.blueGrey,
                                                )
                                              : const Icon(
                                                  Icons.favorite_border),
                                        ),
                                      ));
                                    },
                                    child: Image.network(image,
                                        height: 90, width: 90)),
                              ),
                            ),
                            Text(name,
                                style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w800)),
                            const Text("7pcs, Pricing"),
                            Padding(
                              padding: const EdgeInsets.all(10),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("\$$price",
                                      style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600)),
                                  InkWell(
                                    onTap: () {
                                      provider.addtocart(cartItem);
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: customColors.green,
                                          borderRadius:
                                              BorderRadius.circular(15)),
                                      child: Padding(
                                        padding: const EdgeInsets.all(10),
                                        child: Icon(Icons.add,
                                            color: customColors.white),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            } else {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container();
          },
        ),
      ),
    );
  }
}
