import 'package:flutter/material.dart';
import 'package:groceries_app/constants/colors.dart';
import 'package:groceries_app/view/categories/bevarages_view.dart';
import 'package:groceries_app/view-model/explore_page_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:groceries_app/utils/bottom_navigation.dart';

class ExplorePageView extends StatefulWidget {
  const ExplorePageView({Key? key}) : super(key: key);

  @override
  State<ExplorePageView> createState() => _ExplorePageViewState();
}

class _ExplorePageViewState extends State<ExplorePageView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ExplorePageViewModel>.reactive(
      viewModelBuilder: () => ExplorePageViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              const SizedBox(
                height: 30,
              ),
              const Center(
                  child: Text(
                "Find Products",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              )),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Container(
                  decoration: BoxDecoration(
                    color: customColors.backgroundWhite,
                    borderRadius: const BorderRadius.all(
                      Radius.circular(15),
                    ),
                  ),
                  child: TextFormField(
                    decoration: const InputDecoration(
                        hintText: "Search store",
                        prefixIcon: Icon(Icons.search),
                        border: InputBorder.none),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: GridView(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, childAspectRatio: 0.75),
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        decoration: BoxDecoration(
                          color: customColors.lightBlue,
                          border: Border.all(
                              color: customColors.lightBlueBorder, width: 3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                "assets/categories/fresh_fruits_and_vegetables.png",
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              const Text(
                                "Fresh Fruits",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const Text(
                                "\$ vegetables",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        decoration: BoxDecoration(
                          color: customColors.lightPink,
                          border: Border.all(
                              color: customColors.lightPinkBorder, width: 3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset("assets/categories/cooking_oil.png"),
                              const SizedBox(
                                height: 20,
                              ),
                              const Text(
                                "Cooking Oil",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const Text(
                                "\$ Ghee",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        decoration: BoxDecoration(
                          color: customColors.darkPink,
                          border: Border.all(
                              color: customColors.darkPinkBorder, width: 3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset("assets/categories/meat_&_fish.png"),
                              const SizedBox(
                                height: 20,
                              ),
                              const Text(
                                "Meat & Fish",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        decoration: BoxDecoration(
                          color: customColors.violet,
                          border: Border.all(
                              color: customColors.violetBorder, width: 3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                  "assets/categories/bakery_snacks.png"),
                              const SizedBox(
                                height: 20,
                              ),
                              const Text(
                                "Bakery & Snacks",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        decoration: BoxDecoration(
                          color: customColors.veryLightPink,
                          border: Border.all(
                              color: customColors.veryLightPinkBorder,
                              width: 3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset("assets/categories/dairy_&_eggs.png"),
                              const SizedBox(
                                height: 20,
                              ),
                              const Text(
                                "Dairy & Eggs",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const BeveragesView(),
                          ));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: customColors.lightBlue,
                            border: Border.all(
                                color: customColors.lightBlueBorder, width: 3),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/categories/bevarages.png"),
                                const SizedBox(
                                  height: 20,
                                ),
                                const Text(
                                  "Bevarages",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
