import 'package:flutter/material.dart';
import 'package:groceries_app/view-model/account_view_model.dart';
import 'package:groceries_app/utils/bottom_navigation.dart';
import 'package:groceries_app/view/login_page.dart';
import 'package:stacked/stacked.dart';
import 'package:groceries_app/constants/colors.dart';

class AccountView extends StatefulWidget {
  const AccountView({Key? key}) : super(key: key);

  @override
  State<AccountView> createState() => _AccountViewState();
}

class _AccountViewState extends State<AccountView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AccountViewModel>.reactive(
      viewModelBuilder: () => AccountViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: Column(
          children: [
            const SizedBox(
              height: 440,
            ),
            Padding(
                padding: const EdgeInsets.all(20),
                child: InkWell(
                  onTap: () {
                    viewModel.emailAuth.signOut();
                    Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (context) => const LoginView(),
                        ),
                        (route) => false);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: customColors.green,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                        child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        "Sign Out",
                        style: TextStyle(
                          color: customColors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    )),
                  ),
                )),
          ],
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
