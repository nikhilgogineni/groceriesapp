import 'package:flutter/material.dart';
import 'package:groceries_app/custom_widgets/CustomButton.dart';
import 'package:groceries_app/view/social_media.dart';

class GetStarted extends StatelessWidget {
  const GetStarted({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/images/person_delivary.png"),
            opacity: 1.0,
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 320,
            ),
            Image.asset(
              "assets/images/carrot.png",
              color: Colors.white,
              height: 70,
              width: 70,
            ),
            const Text(
              "Welcome",
              style: TextStyle(
                color: Colors.white,
                fontSize: 40,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              "to our store",
              style: TextStyle(
                color: Colors.white,
                fontSize: 40,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              "Get your Groceries as fast as one hour",
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 40,
                right: 40,
                top: 20,
                bottom: 20,
              ),
              child: InkWell(
                onTap: () {
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(
                        builder: (context) => const SocialMediaView(),
                      ),
                      (route) => false);
                },
                child: const CustomButton(
                    textName: "Get Started",
                    color1: Color(0xFF53b175),
                    color2: Colors.white),
              ),
            ),
          ],
        )),
      ),
    );
  }
}
