import 'package:flutter/material.dart';
import 'package:groceries_app/view/account_view.dart';
import 'package:groceries_app/constants/colors.dart';
import '../view/cart_view.dart';
import '../view/explore_page_view.dart';
import '../view/favorite_view.dart';
import '../view/home_page_view.dart';

class BottomNavigationWidget extends StatefulWidget {
  int selectedIndex;
  BottomNavigationWidget({Key? key, required this.selectedIndex})
      : super(key: key);

  @override
  State<BottomNavigationWidget> createState() => _BottomNavigationWidgetState();
}

class _BottomNavigationWidgetState extends State<BottomNavigationWidget> {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      onTap: (index) {
        widget.selectedIndex = index;
        if (index == 0) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const HomePageView(),
              ),
              (route) => false);
        } else if (index == 1) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const ExplorePageView(),
              ),
              (route) => false);
        } else if (index == 2) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const CartView(),
              ),
              (route) => false);
        } else if (index == 3) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const FavoriteView(),
              ),
              (route) => false);
        } else if (index == 4) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const AccountView(),
              ),
              (route) => false);
        }
      },
      type: BottomNavigationBarType.fixed,
      selectedItemColor: customColors.green,
      unselectedItemColor: customColors.black,
      currentIndex: widget.selectedIndex,
      items: const [
        BottomNavigationBarItem(
          icon: ImageIcon(
            AssetImage(
              "assets/icons/shop.png",
            ),
          ),
          label: "Shop",
        ),
        BottomNavigationBarItem(
            icon: ImageIcon(
              AssetImage(
                "assets/icons/explore.png",
              ),
            ),
            label: "Explore"),
        BottomNavigationBarItem(
            icon: ImageIcon(
              AssetImage(
                "assets/icons/cart.png",
              ),
            ),
            label: "Cart"),
        BottomNavigationBarItem(
            icon: ImageIcon(
              AssetImage(
                "assets/icons/favorite.png",
              ),
            ),
            label: "Favourite"),
        BottomNavigationBarItem(
            icon: ImageIcon(
              AssetImage(
                "assets/icons/account.png",
              ),
            ),
            label: "Account"),
      ],
    );
  }
}
