import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EmailAuthentication {
  FirebaseAuth auth = FirebaseAuth.instance;
  // final reference = FirebaseDatabase.instance.ref("users");
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController usernameController = TextEditingController();

  final reference = FirebaseDatabase.instance.ref("groceries/bevarages");
  final usersRef = FirebaseDatabase.instance.ref("users");

  FirebaseFirestore fs = FirebaseFirestore.instance;

  register() async {
    await auth.createUserWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
    String uid = auth.currentUser!.uid;
    String id = DateTime.now().millisecondsSinceEpoch.toString();
    FirebaseDatabase.instance.ref("users").child(auth.currentUser!.uid).set({
      "username": usernameController.text.toString(),
      "email": emailController.text.toString(),
      "password": passwordController.text.toString(),
      "uid": uid.toString(),
      "id": id.toString(),
    });
  }

  getData() async {
    reference.child("image").get().toString();
  }

  signIn() async {
    await auth.signInWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
  }

  signOut() async {
    await auth.signOut();
  }
}
