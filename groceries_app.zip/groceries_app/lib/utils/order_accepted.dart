import 'package:flutter/material.dart';
import 'package:groceries_app/view/home_page_view.dart';

import '../constants/colors.dart';

class OrderAccepted extends StatelessWidget {
  const OrderAccepted({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(height: 60),
          Center(
            child: Padding(
              padding: const EdgeInsets.only(left: 10, right: 50),
              child: Image.asset("assets/images/order_accepted.png"),
            ),
          ),
          const SizedBox(height: 30),
          const Center(
            child: Text("Your Order has been Accepted",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 20),
          const Text("Your items has been placed and is on"),
          const Text("it's way to being processed"),
          const SizedBox(height: 80),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              decoration: BoxDecoration(
                color: customColors.green,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                  child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  "Track Order",
                  style: TextStyle(
                    color: customColors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )),
            ),
          ),
          TextButton(
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                      builder: (context) => const HomePageView(),
                    ),
                    (route) => false);
              },
              child: Text(
                "Back to Home",
                style: TextStyle(fontSize: 20, color: customColors.black),
              )),
        ],
      ),
    );
  }
}
