import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:groceries_app/view/phone_verify_view.dart';

class PhoneAuthentication {
  FirebaseAuth auth = FirebaseAuth.instance;
  TextEditingController phoneController = TextEditingController();
  TextEditingController verifyController = TextEditingController();
  // String verification = '';

  verifyPhoneNumber(context) async {
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: "+91 8897-578-848",
      verificationCompleted: (PhoneAuthCredential credential) async {},
      verificationFailed: (FirebaseAuthException e) {},
      codeSent: (String verificationId, int? resendToken) {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => const PhoneVerifyView(),
        ));
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  // sighInPhoneNumber() async {
  //   final credential = PhoneAuthProvider.credential(
  //       verificationId: verification, smsCode: verifyController.text);
  //   await auth.signInWithCredential(credential);
  // }
}
